SiteAccess


  The SiteAccess product provides support for pluggable pre-
  traversal methods, and supplies objects and methods which
  can be used to rewrite access URLs at the start of resolution
  and as folders are traversed.

  The main intent is to provide for multi-site hosting in Zope.

  More information is available at http://zope.org/Members/4am/SiteAccess
