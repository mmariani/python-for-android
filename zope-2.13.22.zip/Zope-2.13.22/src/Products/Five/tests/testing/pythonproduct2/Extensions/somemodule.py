

def somemethod(self):
    print "Executed somemethod"
