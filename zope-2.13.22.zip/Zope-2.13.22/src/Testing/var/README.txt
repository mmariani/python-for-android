This directory may be used by some tests (such as the ZEO tests).
